# Dev Container Setup for AWS Portfolio

This directory contains VS Code Dev Container configuration for developing and deploying your AWS portfolio website.

## What's Included

The dev container provides:
- ✅ AWS CLI v2
- ✅ Terraform 1.7.0
- ✅ Git
- ✅ Your AWS credentials (mounted from host)
- ✅ VS Code extensions for Terraform and AWS

## Prerequisites

1. **Docker Desktop** installed and running
2. **VS Code** with "Dev Containers" extension installed
   - Install extension: `ms-vscode-remote.remote-containers`
3. **AWS credentials** configured on your host machine at `~/.aws/`

## Two Configuration Options

### Option 1: Using Pre-built Image (Faster)

Uses `devcontainer.json` - downloads pre-built Microsoft image with features.

**Pros:** Faster startup, maintained by Microsoft
**Cons:** Less customization

### Option 2: Custom Dockerfile (More Control)

Uses `devcontainer-custom.json` and `Dockerfile` - builds custom image.

**Pros:** Full control, reproducible, can add custom tools
**Cons:** Slower first build

**To use Option 2:** Rename `devcontainer-custom.json` to `devcontainer.json`

## Quick Start

### 1. Setup Your Project Directory

```bash
# Create project directory
mkdir aws-portfolio
cd aws-portfolio

# Copy all project files here
# - index.html
# - main.tf
# - terraform.tfvars.example
# - .devcontainer/ (this directory)
```

### 2. Configure AWS Credentials on Host

**If you haven't already:**

```bash
# On your macOS host (NOT in container)
aws configure
```

Enter your AWS credentials. This creates `~/.aws/credentials` and `~/.aws/config`.

### 3. Open in VS Code

```bash
code .
```

### 4. Reopen in Container

When VS Code opens, you'll see a popup:
**"Folder contains a Dev Container configuration file. Reopen folder to develop in a container?"**

Click **"Reopen in Container"**

Or use Command Palette (Cmd+Shift+P):
- Type: "Dev Containers: Reopen in Container"

### 5. Wait for Container to Build

First time takes 2-5 minutes (downloads images, installs tools).
Subsequent opens are much faster.

### 6. Verify Setup

Once the container is ready, open a terminal in VS Code:

```bash
# Check AWS CLI
aws --version
# Output: aws-cli/2.x.x

# Check Terraform
terraform --version
# Output: Terraform v1.7.0

# Verify AWS credentials work
aws sts get-caller-identity
# Should show your AWS account details
```

## Deploying Your Website from Dev Container

Now you can follow the deployment steps:

```bash
# 1. Configure Terraform
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars with your bucket name

# 2. Customize index.html
# Edit with your actual information

# 3. Initialize Terraform
terraform init

# 4. Preview changes
terraform plan

# 5. Deploy infrastructure
terraform apply
# Type 'yes' when prompted

# 6. Upload website
aws s3 cp index.html s3://YOUR-BUCKET-NAME/

# 7. Get your website URL
terraform output website_url
```

## Useful VS Code Features in Container

### Terraform Extension Features
- Syntax highlighting
- Auto-completion
- Format on save
- Validation

### AWS Toolkit Features
- Browse S3 buckets
- View CloudFront distributions
- Access CloudWatch logs

## Troubleshooting

### AWS Credentials Not Working

**Problem:** `aws sts get-caller-identity` fails

**Solutions:**
1. Verify credentials exist on host: `cat ~/.aws/credentials`
2. Rebuild container: Cmd+Shift+P → "Dev Containers: Rebuild Container"
3. Check mount path in devcontainer.json matches your OS

### Container Won't Start

**Problem:** Docker error on startup

**Solutions:**
1. Ensure Docker Desktop is running
2. Check Docker has enough resources (Settings → Resources)
3. Try: Cmd+Shift+P → "Dev Containers: Rebuild Container Without Cache"

### Terraform/AWS CLI Not Found

**Problem:** Commands not available in terminal

**Solutions:**
1. Wait for postCreateCommand to finish (check terminal output)
2. Rebuild container
3. Check devcontainer.json syntax

### Permission Errors

**Problem:** Can't write files or run commands

**Solution:** Dev container should use `vscode` user automatically. If issues persist, check `remoteUser` in devcontainer.json

## Managing the Container

### Rebuild Container
Cmd+Shift+P → "Dev Containers: Rebuild Container"

### Close Container
Just close VS Code, or:
Cmd+Shift+P → "Dev Containers: Reopen Folder Locally"

### Delete Container & Images
```bash
# List containers
docker ps -a

# Remove container
docker rm <container-id>

# Remove image (to free space)
docker images
docker rmi <image-id>
```

## Customizing the Container

### Add More Tools

Edit `Dockerfile` and add to the `apt-get install` section:

```dockerfile
RUN apt-get update && apt-get install -y \
    curl \
    unzip \
    git \
    vim \
    jq \
    htop \      # Add new tool
    && rm -rf /var/lib/apt/lists/*
```

### Add VS Code Extensions

Edit `devcontainer.json`:

```json
"extensions": [
  "hashicorp.terraform",
  "amazonwebservices.aws-toolkit-vscode",
  "your.extension.id"  // Add here
]
```

### Change Terraform Version

Edit `Dockerfile`:
```dockerfile
ARG TERRAFORM_VERSION=1.8.0  # Change version
```

Then rebuild container.

## Benefits of Dev Container

✅ **Consistent Environment** - Same setup on any machine
✅ **No Host Pollution** - Tools isolated in container
✅ **Easy Sharing** - Others can use same setup
✅ **Version Control** - Configuration in Git
✅ **Quick Cleanup** - Delete container when done

## Security Notes

- AWS credentials are mounted **read-only** from host
- Container runs as non-root user (`vscode`)
- Credentials never committed to Git (in .gitignore)

## Next Steps

Once your site is deployed from the container:
1. Test your website URL
2. Update content as needed
3. Consider adding CI/CD for automated deployments

---

**Questions?** The dev container terminal works exactly like your regular terminal, just with all the tools pre-installed!
